module Tmdb
  class Media < Struct
  end
end
