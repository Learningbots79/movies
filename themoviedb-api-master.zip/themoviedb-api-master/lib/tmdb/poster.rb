module Tmdb
  class Poster < Struct
  end
end
