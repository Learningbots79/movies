module Tmdb
  class Account < Struct
  end
end
