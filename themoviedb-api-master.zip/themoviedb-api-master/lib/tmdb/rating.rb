module Tmdb
  class Rating < Struct
  end
end
