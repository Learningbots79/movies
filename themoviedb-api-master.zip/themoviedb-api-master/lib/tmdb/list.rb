module Tmdb
  class List < Struct
  end
end
