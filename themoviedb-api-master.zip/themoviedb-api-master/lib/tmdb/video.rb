module Tmdb
  class Video < Struct
  end
end
