module Tmdb
  class Error < ::StandardError
  end
end
