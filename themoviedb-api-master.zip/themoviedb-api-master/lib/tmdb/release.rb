module Tmdb
  class Release < Struct
  end
end
