module Tmdb
  class Country < Struct
  end
end
