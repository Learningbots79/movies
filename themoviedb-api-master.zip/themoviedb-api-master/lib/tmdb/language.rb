module Tmdb
  class Language < Struct
  end
end
