module Tmdb
  VERSION = '1.4.1'
end
