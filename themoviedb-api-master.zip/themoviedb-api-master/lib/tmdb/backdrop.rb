module Tmdb
  class Backdrop < Struct
  end
end
