module Tmdb
  class Authentication < Struct
  end
end
