module Tmdb
  class ChangeItem < Struct
  end
end
