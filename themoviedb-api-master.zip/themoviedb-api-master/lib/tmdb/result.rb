module Tmdb
  class Result < Struct
  end
end
