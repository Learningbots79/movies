module Tmdb
  class Multi < Struct
  end
end
