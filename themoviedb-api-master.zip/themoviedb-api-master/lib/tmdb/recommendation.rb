module Tmdb
  class Recommendation < Struct
  end
end
