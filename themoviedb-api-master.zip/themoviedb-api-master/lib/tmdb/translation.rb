module Tmdb
  class Translation < Struct
  end
end
